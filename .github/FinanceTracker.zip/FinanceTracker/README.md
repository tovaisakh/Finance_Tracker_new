# 💰 Finance Tracker — Android App

A fully-featured personal finance tracker for Android that **automatically detects transactions from SMS bank alerts**, supports manual entry, categorizes spending, and shows analytics — all stored locally on your device.

---

## ✨ Features

| Feature | Details |
|---|---|
| **Auto SMS Parsing** | Detects transactions from HDFC, ICICI, SBI, Axis, Kotak, Yes Bank, PNB, Paytm, PhonePe, and more |
| **Smart Categorization** | Food, Groceries, Transport, Shopping, Entertainment, Utilities, Health, Travel, Transfers, ATM, and more |
| **Transfer Detection** | Separately tracks money you send to others via UPI/NEFT/IMPS |
| **Dashboard** | Monthly income, expenses, balance at a glance |
| **Transaction History** | Full list with search, type filters, category filters |
| **Analytics** | Category breakdown, savings rate, multi-period view |
| **Manual Entry** | Add/edit any transaction manually |
| **Onboarding Wizard** | 4-step setup guides you through permissions |
| **Duplicate Detection** | Prevents double-logging of the same transaction |
| **Local SQLite Storage** | Zero cloud dependency — your data never leaves your phone |

---

## 🏗️ How to Build the APK

### Option 1 — Android Studio (Recommended, ~10 min)

1. **Install Android Studio**: https://developer.android.com/studio
2. **Open the project**: File → Open → select the `FinanceTracker` folder
3. Wait for Gradle sync to complete (~2–3 min on first run)
4. **Build Debug APK**: Build → Build Bundle(s) / APK(s) → Build APK(s)
5. APK will be at: `app/build/outputs/apk/debug/app-debug.apk`
6. **Install on phone**: Connect via USB, enable USB Debugging, then:
   ```
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```
   Or copy the APK file to your phone and open it.

### Option 2 — GitHub Actions (No local setup needed)

1. Create a new GitHub repository
2. Push this project to it:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/finance-tracker.git
   git push -u origin main
   ```
3. Go to **Actions** tab in GitHub
4. The workflow runs automatically — click it to watch progress
5. When complete, click **Artifacts** to download the APK
6. Transfer the APK to your Android phone and install it

### Option 3 — Command Line (if you have Android SDK installed)

```bash
# Set your Android SDK path
export ANDROID_HOME=$HOME/Android/Sdk  # Linux/Mac
# or: set ANDROID_HOME=C:\Users\YOU\AppData\Local\Android\Sdk  (Windows)

chmod +x gradlew
./gradlew assembleDebug

# APK location:
ls app/build/outputs/apk/debug/
```

---

## 📱 Installing the APK on Your Phone

1. Transfer the `.apk` file to your Android phone (USB, email, Google Drive, etc.)
2. On your phone: **Settings → Security → Install Unknown Apps** → enable for your file manager
3. Open the APK file and tap **Install**
4. Open **Finance Tracker** and follow the setup wizard

---

## 🔐 Permissions Explained

| Permission | Why It's Needed |
|---|---|
| `READ_SMS` | Read existing bank SMS to import transaction history |
| `RECEIVE_SMS` | Detect new bank SMS in real time |
| `POST_NOTIFICATIONS` | Notify you when new transactions are detected |
| `INTERNET` | Not used for tracking — reserved for future email sync |
| `RECEIVE_BOOT_COMPLETED` | Ensure SMS detection restarts after phone reboot |

**No data is ever sent to any server.** All transaction data lives in a local SQLite database on your device.

---

## 🏦 Supported Banks (SMS Detection)

**India:** HDFC Bank, ICICI Bank, SBI, Axis Bank, Kotak Mahindra, Yes Bank, PNB, Bank of Baroda, Canara Bank, Union Bank, IPPB, IndusInd Bank

**Payment Apps:** Paytm, PhonePe, Google Pay, Amazon Pay, FreeCharge

**International:** Citi, HSBC, Standard Chartered, Deutsche Bank, Amex

*More banks are supported if their SMS follows standard debit/credit patterns.*

---

## 📂 Project Structure

```
FinanceTracker/
├── app/src/main/
│   ├── java/com/financetracker/
│   │   ├── data/
│   │   │   ├── Transaction.kt          # Data models + categories
│   │   │   ├── DatabaseHelper.kt       # SQLite CRUD operations
│   │   │   └── TransactionRepository.kt # Single source of truth
│   │   ├── service/
│   │   │   ├── SmsParser.kt            # Core SMS parsing engine
│   │   │   ├── EmailParser.kt          # Email body parsing
│   │   │   └── EmailSyncService.kt     # Background SMS history scan
│   │   ├── receiver/
│   │   │   ├── SmsReceiver.kt          # Real-time SMS BroadcastReceiver
│   │   │   └── BootReceiver.kt         # Restart after reboot
│   │   └── ui/
│   │       ├── SplashActivity.kt       # Launch screen
│   │       ├── SetupActivity.kt        # First-run onboarding
│   │       ├── MainActivity.kt         # Navigation host
│   │       ├── DashboardFragment.kt    # Home screen summary
│   │       ├── TransactionsFragment.kt # Full transaction list
│   │       ├── AnalyticsFragment.kt    # Charts + breakdown
│   │       ├── AddTransactionActivity.kt # Manual add/edit
│   │       └── TransactionAdapter.kt   # RecyclerView adapter
│   ├── res/
│   │   ├── layout/                     # All XML layouts
│   │   ├── values/                     # Colors, strings, themes
│   │   ├── drawable/                   # Icons, backgrounds
│   │   ├── menu/                       # Bottom navigation menu
│   │   ├── color/                      # Color state lists
│   │   └── xml/                        # Network security config
│   └── AndroidManifest.xml
├── .github/workflows/build.yml         # GitHub Actions CI/CD
├── build.gradle                        # Root build config
├── app/build.gradle                    # App dependencies
└── README.md
```

---

## 🛠️ Tech Stack

- **Language:** Kotlin
- **Min SDK:** API 24 (Android 7.0) — covers ~94% of devices
- **Database:** SQLite via custom `DatabaseHelper`
- **UI:** Material Design 3 Components
- **Architecture:** Simple MVP-lite (Fragment + Repository)
- **Background:** BroadcastReceiver + Service

---

## 🔄 How SMS Parsing Works

1. Bank sends an SMS: *"INR 2,500.00 debited from A/c xx4521 on 20-Apr-26 at SWIGGY. Avl Bal: INR 18,432.10"*
2. `SmsReceiver` catches it instantly via `android.provider.Telephony.SMS_RECEIVED`
3. `SmsParser.parse()` runs regex patterns to extract:
   - Amount → `2500.00`
   - Type → `EXPENSE` (saw "debited")
   - Merchant → `SWIGGY`
   - Category → `Food & Dining` (matched keyword "swiggy")
   - Account → `4521`
4. Duplicate check: has this exact amount+description been logged in the last 5 minutes?
5. If unique → saved to SQLite → appears in your transaction list instantly

---

## 📈 Roadmap / Future Enhancements

- [ ] Gmail OAuth integration for email transaction parsing
- [ ] Budget limits per category with alerts
- [ ] Export to CSV/Excel
- [ ] Monthly/yearly comparison charts
- [ ] PIN/biometric app lock
- [ ] Widget for home screen balance
- [ ] Dark mode support

---

*Built with ❤️ for anyone who wants to know where their money actually goes.*
