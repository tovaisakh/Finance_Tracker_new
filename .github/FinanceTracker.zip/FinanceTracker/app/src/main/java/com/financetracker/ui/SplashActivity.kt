package com.financetracker.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.financetracker.R

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({
            val prefs = getSharedPreferences("finance_tracker", MODE_PRIVATE)
            val setupDone = prefs.getBoolean("setup_done", false)
            val target = if (setupDone) MainActivity::class.java else SetupActivity::class.java
            startActivity(Intent(this, target))
            finish()
        }, 1200)
    }
}
