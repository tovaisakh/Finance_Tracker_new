package com.financetracker.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.financetracker.data.DatabaseHelper
import com.financetracker.service.SmsParser
import java.util.Date

class SmsReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "FinanceTracker.SMS"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val dbHelper = DatabaseHelper(context)

        for (sms in messages) {
            val sender = sms.originatingAddress ?: continue
            val body = sms.messageBody ?: continue
            val timestamp = Date(sms.timestampMillis)

            Log.d(TAG, "Received SMS from: $sender")

            try {
                val result = SmsParser.parse(sender, body)
                val transaction = result.transaction ?: continue

                // Timestamp from actual SMS delivery
                val transactionWithTime = transaction.copy(date = timestamp)

                // Duplicate check
                if (!dbHelper.isDuplicateTransaction(
                        transactionWithTime.amount,
                        transactionWithTime.date,
                        transactionWithTime.description
                    )) {
                    val id = dbHelper.insertTransaction(transactionWithTime)
                    Log.d(TAG, "Saved transaction id=$id, amount=${transactionWithTime.amount}, confidence=${result.confidence}")
                } else {
                    Log.d(TAG, "Duplicate transaction skipped")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error parsing SMS", e)
            }
        }
    }
}
