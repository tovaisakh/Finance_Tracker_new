package com.financetracker.ui

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.financetracker.data.Categories
import com.financetracker.data.Transaction
import com.financetracker.data.TransactionRepository
import com.financetracker.data.TransactionSource
import com.financetracker.data.TransactionType
import com.financetracker.databinding.ActivityAddTransactionBinding
import java.text.SimpleDateFormat
import java.util.*

class AddTransactionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddTransactionBinding
    private lateinit var repo: TransactionRepository
    private var selectedDate = Date()
    private var editingId: Long = -1L
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTransactionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = TransactionRepository(this)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        editingId = intent.getLongExtra("transaction_id", -1L)
        if (editingId != -1L) {
            supportActionBar?.title = "Edit Transaction"
            loadExistingTransaction()
        } else {
            supportActionBar?.title = "Add Transaction"
        }

        setupCategoryDropdown()
        setupDatePicker()
        setupSaveButton()
        setupTypeRadioGroup()
    }

    private fun setupTypeRadioGroup() {
        binding.rgType.setOnCheckedChangeListener { _, checkedId ->
            updateCategoryList()
        }
    }

    private fun setupCategoryDropdown() {
        updateCategoryList()
    }

    private fun updateCategoryList() {
        val isIncome = binding.rbIncome.isChecked
        val cats = if (isIncome) Categories.INCOME_CATEGORIES else Categories.EXPENSE_CATEGORIES
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, cats)
        binding.actvCategory.setAdapter(adapter)
        if (binding.actvCategory.text.isNullOrBlank()) {
            binding.actvCategory.setText(cats.first(), false)
        }
    }

    private fun setupDatePicker() {
        binding.tvDate.text = dateFmt.format(selectedDate)
        binding.tvDate.setOnClickListener {
            val cal = Calendar.getInstance().apply { time = selectedDate }
            DatePickerDialog(this, { _, y, m, d ->
                cal.set(y, m, d)
                selectedDate = cal.time
                binding.tvDate.text = dateFmt.format(selectedDate)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
    }

    private fun setupSaveButton() {
        binding.btnSave.setOnClickListener { saveTransaction() }
    }

    private fun saveTransaction() {
        val amountStr = binding.etAmount.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()
        val category = binding.actvCategory.text.toString().trim()
        val merchant = binding.etMerchant.text.toString().trim()

        if (amountStr.isBlank()) {
            binding.etAmount.error = "Amount is required"
            return
        }
        val amount = amountStr.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            binding.etAmount.error = "Enter a valid amount"
            return
        }
        if (category.isBlank()) {
            binding.actvCategory.error = "Category is required"
            return
        }

        val type = when {
            binding.rbIncome.isChecked -> TransactionType.INCOME
            binding.rbTransfer.isChecked -> TransactionType.TRANSFER
            else -> TransactionType.EXPENSE
        }

        val transaction = Transaction(
            id = if (editingId != -1L) editingId else 0,
            amount = amount,
            type = type,
            category = category,
            description = description.ifBlank { "$type - $category" },
            merchant = merchant,
            date = selectedDate,
            source = TransactionSource.MANUAL,
            isVerified = true
        )

        if (editingId != -1L) {
            repo.updateTransaction(transaction)
            Toast.makeText(this, "Transaction updated ✓", Toast.LENGTH_SHORT).show()
        } else {
            repo.addTransaction(transaction)
            Toast.makeText(this, "Transaction added ✓", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    private fun loadExistingTransaction() {
        val all = repo.getAll()
        val t = all.find { it.id == editingId } ?: return
        binding.etAmount.setText(t.amount.toString())
        binding.etDescription.setText(t.description)
        binding.etMerchant.setText(t.merchant)
        binding.actvCategory.setText(t.category, false)
        selectedDate = t.date
        binding.tvDate.text = dateFmt.format(t.date)
        when (t.type) {
            TransactionType.INCOME -> binding.rbIncome.isChecked = true
            TransactionType.EXPENSE -> binding.rbExpense.isChecked = true
            TransactionType.TRANSFER -> binding.rbTransfer.isChecked = true
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
