package com.financetracker.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.financetracker.data.TransactionRepository
import com.financetracker.databinding.FragmentAnalyticsBinding
import java.text.NumberFormat
import java.util.Locale

class AnalyticsFragment : Fragment() {

    private var _binding: FragmentAnalyticsBinding? = null
    private val binding get() = _binding!!
    private lateinit var repo: TransactionRepository

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAnalyticsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repo = TransactionRepository(requireContext())
        loadAnalytics()
        setupPeriodSelector()
    }

    private var currentPeriod = TransactionRepository.Period.THIS_MONTH

    private fun setupPeriodSelector() {
        binding.chipPeriodMonth.setOnCheckedChangeListener { _, checked ->
            if (checked) { currentPeriod = TransactionRepository.Period.THIS_MONTH; loadAnalytics() }
        }
        binding.chipPeriodWeek.setOnCheckedChangeListener { _, checked ->
            if (checked) { currentPeriod = TransactionRepository.Period.THIS_WEEK; loadAnalytics() }
        }
        binding.chipPeriodAll.setOnCheckedChangeListener { _, checked ->
            if (checked) { currentPeriod = TransactionRepository.Period.ALL_TIME; loadAnalytics() }
        }
    }

    private fun loadAnalytics() {
        val fmt = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        val summary = repo.getSummary(currentPeriod)
        val categoryTotals = repo.getExpenseByCategory(currentPeriod)

        // Summary
        binding.tvAnalyticsIncome.text = "Income: ${fmt.format(summary.totalIncome)}"
        binding.tvAnalyticsExpenses.text = "Expenses: ${fmt.format(summary.totalExpenses)}"
        binding.tvAnalyticsBalance.text = "Net: ${fmt.format(summary.balance)}"
        binding.tvAnalyticsTransfers.text = "Transfers: ${fmt.format(summary.totalTransfers)}"

        // Category breakdown as text bars
        val sb = StringBuilder()
        val total = categoryTotals.values.sum().takeIf { it > 0 } ?: 1.0
        categoryTotals.entries.take(8).forEach { (cat, amount) ->
            val pct = (amount / total * 100).toInt()
            val bar = "█".repeat(pct / 5) + "░".repeat(20 - pct / 5)
            sb.append("${cat.padEnd(20)} $bar ${fmt.format(amount)} ($pct%)\n\n")
        }
        binding.tvCategoryBreakdown.text = if (sb.isNotEmpty()) sb.toString().trim()
        else "No expense data for this period."

        // Savings rate
        val savingsRate = if (summary.totalIncome > 0)
            ((summary.totalIncome - summary.totalExpenses) / summary.totalIncome * 100).toInt()
        else 0
        binding.tvSavingsRate.text = "Savings Rate: $savingsRate%"
        binding.tvSavingsRate.setTextColor(
            if (savingsRate >= 20) Color.parseColor("#4CAF50")
            else if (savingsRate >= 0) Color.parseColor("#FF9800")
            else Color.parseColor("#F44336")
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
