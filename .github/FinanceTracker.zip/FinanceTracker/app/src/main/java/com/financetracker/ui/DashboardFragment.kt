package com.financetracker.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.financetracker.data.TransactionRepository
import com.financetracker.databinding.FragmentDashboardBinding
import java.text.NumberFormat
import java.util.Locale

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private lateinit var repo: TransactionRepository

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repo = TransactionRepository(requireContext())
        loadDashboard()
    }

    override fun onResume() {
        super.onResume()
        loadDashboard()
    }

    private fun loadDashboard() {
        val fmt = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

        // This month summary
        val summary = repo.getSummary(TransactionRepository.Period.THIS_MONTH)
        binding.tvTotalIncome.text = fmt.format(summary.totalIncome)
        binding.tvTotalExpenses.text = fmt.format(summary.totalExpenses)
        binding.tvBalance.text = fmt.format(summary.balance)

        // Balance color
        binding.tvBalance.setTextColor(
            if (summary.balance >= 0) resources.getColor(android.R.color.holo_green_dark, null)
            else resources.getColor(android.R.color.holo_red_dark, null)
        )

        // Top categories
        val categoryTotals = repo.getExpenseByCategory(TransactionRepository.Period.THIS_MONTH)
        val topCategories = categoryTotals.entries.take(5)

        val sb = StringBuilder()
        topCategories.forEach { (cat, amount) ->
            sb.append("$cat: ${fmt.format(amount)}\n")
        }
        binding.tvTopCategories.text = if (sb.isNotEmpty()) sb.toString().trim()
        else "No expenses this month yet."

        // Recent transactions
        val recent = repo.getRecent(5)
        val adapter = TransactionAdapter(recent) {}
        binding.rvRecentTransactions.adapter = adapter

        // Period note
        binding.tvPeriodNote.text = "Summary for this month"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
