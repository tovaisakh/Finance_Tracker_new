package com.financetracker.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.financetracker.databinding.ActivitySetupBinding

class SetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySetupBinding
    private var currentStep = 0

    private val steps = listOf(
        SetupStep(
            emoji = "👋",
            title = "Welcome to Finance Tracker",
            body = "Automatically track all your income, expenses, and transfers — powered by your SMS bank alerts.\n\nYour data stays 100% on your device. Nothing is uploaded to any server.",
            buttonText = "Get Started"
        ),
        SetupStep(
            emoji = "📱",
            title = "SMS Permission",
            body = "Finance Tracker reads your bank SMS alerts to detect transactions automatically.\n\nSupported banks: HDFC, ICICI, SBI, Axis, Kotak, Yes Bank, PNB, Paytm, PhonePe, and more.\n\nTap Continue to grant SMS permission.",
            buttonText = "Continue"
        ),
        SetupStep(
            emoji = "🗂️",
            title = "Scan Past Messages",
            body = "We'll scan your last 500 SMS messages to import existing transactions.\n\nThis is a one-time scan. Afterwards, new transactions are detected in real time.",
            buttonText = "Scan Now"
        ),
        SetupStep(
            emoji = "✅",
            title = "You're All Set!",
            body = "Finance Tracker is ready.\n\n• Dashboard — monthly summary\n• Transactions — full history + search\n• Analytics — spending breakdown\n• + Button — add transactions manually\n\nTap any bank SMS to see it auto-logged!",
            buttonText = "Open App"
        )
    )

    data class SetupStep(
        val emoji: String,
        val title: String,
        val body: String,
        val buttonText: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        showStep(0)

        binding.btnNext.setOnClickListener { handleStepAction() }
        binding.btnSkip.setOnClickListener { finishSetup() }
    }

    private fun showStep(index: Int) {
        val step = steps[index]
        binding.tvEmoji.text = step.emoji
        binding.tvTitle.text = step.title
        binding.tvBody.text = step.body
        binding.btnNext.text = step.buttonText
        binding.tvStepIndicator.text = "${index + 1} / ${steps.size}"
        binding.btnSkip.visibility = if (index == steps.size - 1)
            android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun handleStepAction() {
        when (currentStep) {
            1 -> {
                // Permission is requested in MainActivity; just advance
                currentStep++
                showStep(currentStep)
            }
            steps.size - 1 -> finishSetup()
            else -> {
                currentStep++
                showStep(currentStep)
            }
        }
    }

    private fun finishSetup() {
        getSharedPreferences("finance_tracker", MODE_PRIVATE)
            .edit().putBoolean("setup_done", true).apply()
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
