package com.financetracker.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.financetracker.R
import com.financetracker.data.Categories
import com.financetracker.data.Transaction
import com.financetracker.data.TransactionRepository
import com.financetracker.data.TransactionType
import com.financetracker.databinding.FragmentTransactionsBinding

class TransactionsFragment : Fragment() {

    private var _binding: FragmentTransactionsBinding? = null
    private val binding get() = _binding!!
    private lateinit var repo: TransactionRepository
    private lateinit var adapter: TransactionAdapter

    private var filterType: TransactionType? = null
    private var filterCategory: String? = null
    private var searchQuery: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTransactionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repo = TransactionRepository(requireContext())

        setupRecyclerView()
        setupSearch()
        setupFilters()
        loadTransactions()
    }

    override fun onResume() {
        super.onResume()
        loadTransactions()
    }

    private fun setupRecyclerView() {
        adapter = TransactionAdapter(emptyList()) { transaction ->
            showTransactionOptions(transaction)
        }
        binding.rvTransactions.adapter = adapter
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString() ?: ""
                loadTransactions()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupFilters() {
        binding.chipAll.setOnCheckedChangeListener { _, checked ->
            if (checked) { filterType = null; loadTransactions() }
        }
        binding.chipIncome.setOnCheckedChangeListener { _, checked ->
            if (checked) { filterType = TransactionType.INCOME; loadTransactions() }
        }
        binding.chipExpense.setOnCheckedChangeListener { _, checked ->
            if (checked) { filterType = TransactionType.EXPENSE; loadTransactions() }
        }
        binding.chipTransfer.setOnCheckedChangeListener { _, checked ->
            if (checked) { filterType = TransactionType.TRANSFER; loadTransactions() }
        }
        binding.btnFilterCategory.setOnClickListener { showCategoryFilter() }
    }

    private fun showCategoryFilter() {
        val cats = listOf("All Categories") + Categories.ALL_CATEGORIES
        AlertDialog.Builder(requireContext())
            .setTitle("Filter by Category")
            .setItems(cats.toTypedArray()) { _, which ->
                filterCategory = if (which == 0) null else cats[which]
                binding.btnFilterCategory.text = if (which == 0) "Category" else cats[which]
                loadTransactions()
            }
            .show()
    }

    private fun loadTransactions() {
        val transactions = repo.getAll(
            type = filterType,
            category = filterCategory,
            search = searchQuery.ifBlank { null }
        )
        adapter.updateData(transactions)

        binding.tvEmpty.visibility = if (transactions.isEmpty()) View.VISIBLE else View.GONE
        binding.tvTransactionCount.text = "${transactions.size} transaction${if (transactions.size != 1) "s" else ""}"
    }

    private fun showTransactionOptions(transaction: Transaction) {
        val options = arrayOf("Edit", "Delete", "View Raw Message")
        AlertDialog.Builder(requireContext())
            .setTitle("Transaction Options")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val intent = Intent(requireContext(), AddTransactionActivity::class.java)
                        intent.putExtra("transaction_id", transaction.id)
                        startActivity(intent)
                    }
                    1 -> confirmDelete(transaction)
                    2 -> showRawMessage(transaction)
                }
            }
            .show()
    }

    private fun confirmDelete(transaction: Transaction) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Transaction")
            .setMessage("Are you sure you want to delete this transaction?")
            .setPositiveButton("Delete") { _, _ ->
                repo.deleteTransaction(transaction.id)
                loadTransactions()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showRawMessage(transaction: Transaction) {
        AlertDialog.Builder(requireContext())
            .setTitle("Raw Message (${transaction.source.name})")
            .setMessage(transaction.rawMessage.ifBlank { "No raw message stored." })
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
