package com.financetracker.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.financetracker.R
import com.financetracker.data.Categories
import com.financetracker.data.Transaction
import com.financetracker.data.TransactionType
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale

class TransactionAdapter(
    private var transactions: List<Transaction>,
    private val onItemClick: (Transaction) -> Unit
) : RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

    private val fmt = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    private val dateFmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvIcon: TextView = itemView.findViewById(R.id.tv_icon)
        val tvDescription: TextView = itemView.findViewById(R.id.tv_description)
        val tvCategory: TextView = itemView.findViewById(R.id.tv_category)
        val tvDate: TextView = itemView.findViewById(R.id.tv_date)
        val tvAmount: TextView = itemView.findViewById(R.id.tv_amount)
        val tvSource: TextView = itemView.findViewById(R.id.tv_source)
        val card: CardView = itemView.findViewById(R.id.card_transaction)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_transaction, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val t = transactions[position]

        holder.tvIcon.text = Categories.CATEGORY_ICONS[t.category] ?: "💳"
        holder.tvDescription.text = t.description.ifBlank { t.category }
        holder.tvCategory.text = t.category
        holder.tvDate.text = dateFmt.format(t.date)
        holder.tvSource.text = t.source.name

        val amountStr = fmt.format(t.amount)
        when (t.type) {
            TransactionType.INCOME -> {
                holder.tvAmount.text = "+$amountStr"
                holder.tvAmount.setTextColor(Color.parseColor("#4CAF50"))
            }
            TransactionType.EXPENSE -> {
                holder.tvAmount.text = "-$amountStr"
                holder.tvAmount.setTextColor(Color.parseColor("#F44336"))
            }
            TransactionType.TRANSFER -> {
                holder.tvAmount.text = "↔ $amountStr"
                holder.tvAmount.setTextColor(Color.parseColor("#FF9800"))
            }
        }

        if (!t.isVerified) {
            holder.card.setCardBackgroundColor(Color.parseColor("#FFF9C4"))
        } else {
            holder.card.setCardBackgroundColor(Color.WHITE)
        }

        holder.itemView.setOnClickListener { onItemClick(t) }
    }

    override fun getItemCount() = transactions.size

    fun updateData(newData: List<Transaction>) {
        transactions = newData
        notifyDataSetChanged()
    }
}
