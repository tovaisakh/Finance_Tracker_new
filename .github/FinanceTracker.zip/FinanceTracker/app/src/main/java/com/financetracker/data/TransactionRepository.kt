package com.financetracker.data

import android.content.Context
import java.util.Calendar
import java.util.Date

class TransactionRepository(context: Context) {
    private val db = DatabaseHelper(context)

    fun addTransaction(transaction: Transaction): Long = db.insertTransaction(transaction)

    fun updateTransaction(transaction: Transaction): Boolean = db.updateTransaction(transaction) > 0

    fun deleteTransaction(id: Long): Boolean = db.deleteTransaction(id) > 0

    fun getAll(
        type: TransactionType? = null,
        category: String? = null,
        search: String? = null,
        start: Date? = null,
        end: Date? = null
    ) = db.getAllTransactions(type = type, category = category, searchQuery = search, startDate = start, endDate = end)

    fun getRecent(count: Int = 20) = db.getAllTransactions(limit = count)

    fun getSummary(period: Period = Period.THIS_MONTH): Summary {
        val (start, end) = period.dateRange()
        val income = db.getTotalByType(TransactionType.INCOME, start, end)
        val expenses = db.getTotalByType(TransactionType.EXPENSE, start, end)
        val transfers = db.getTotalByType(TransactionType.TRANSFER, start, end)
        return Summary(income, expenses, transfers, income - expenses - transfers)
    }

    fun getExpenseByCategory(period: Period = Period.THIS_MONTH): Map<String, Double> {
        val (start, end) = period.dateRange()
        return db.getCategoryTotals(TransactionType.EXPENSE, start, end)
    }

    fun isDuplicate(amount: Double, date: Date, description: String) =
        db.isDuplicateTransaction(amount, date, description)

    data class Summary(
        val totalIncome: Double,
        val totalExpenses: Double,
        val totalTransfers: Double,
        val balance: Double
    )

    enum class Period {
        TODAY, THIS_WEEK, THIS_MONTH, LAST_MONTH, ALL_TIME;

        fun dateRange(): Pair<Date?, Date?> {
            val cal = Calendar.getInstance()
            return when (this) {
                TODAY -> {
                    cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                    Pair(cal.time, Date())
                }
                THIS_WEEK -> {
                    cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
                    cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
                    Pair(cal.time, Date())
                }
                THIS_MONTH -> {
                    cal.set(Calendar.DAY_OF_MONTH, 1)
                    cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
                    Pair(cal.time, Date())
                }
                LAST_MONTH -> {
                    cal.add(Calendar.MONTH, -1)
                    cal.set(Calendar.DAY_OF_MONTH, 1)
                    val start = cal.time
                    cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
                    Pair(start, cal.time)
                }
                ALL_TIME -> Pair(null, null)
            }
        }
    }
}
