package com.financetracker.service

import com.financetracker.data.Categories
import com.financetracker.data.Transaction
import com.financetracker.data.TransactionSource
import com.financetracker.data.TransactionType
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern

object SmsParser {

    data class ParseResult(
        val transaction: Transaction?,
        val confidence: Float // 0.0 - 1.0
    )

    // Amount patterns: ₹1,234.56 | Rs.1234 | INR 1234 | USD 12.34
    private val AMOUNT_PATTERNS = listOf(
        Pattern.compile("""(?:Rs\.?|INR|₹)\s*([0-9,]+(?:\.[0-9]{1,2})?)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""([0-9,]+(?:\.[0-9]{1,2})?)\s*(?:Rs\.?|INR|₹)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""(?:USD|EUR|GBP|AUD)\s*([0-9,]+(?:\.[0-9]{1,2})?)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""amount\s+(?:of\s+)?(?:Rs\.?|INR|₹)?\s*([0-9,]+(?:\.[0-9]{1,2})?)""", Pattern.CASE_INSENSITIVE)
    )

    // Debit indicators
    private val DEBIT_KEYWORDS = setOf(
        "debited", "debit", "spent", "paid", "payment", "purchase", "charged",
        "withdrawn", "withdrawal", "transferred to", "sent to", "transfer to",
        "transaction at", "used at", "pos purchase", "atm withdrawal", "deducted",
        "bill pay", "emi", "mandate executed"
    )

    // Credit indicators
    private val CREDIT_KEYWORDS = setOf(
        "credited", "credit", "received", "deposited", "deposit", "salary",
        "transferred from", "received from", "refund", "cashback", "interest credited",
        "dividend", "added to", "neft credit", "imps credit", "upi credit"
    )

    // Transfer-out indicators
    private val TRANSFER_OUT_KEYWORDS = setOf(
        "transferred to", "sent to", "transfer to", "you sent", "paid to",
        "neft to", "imps to", "upi to", "money sent", "amount transferred to"
    )

    // Bank sender IDs (India focused + international)
    private val BANK_SENDERS = setOf(
        "HDFCBK", "ICICIB", "SBIINB", "AXISBK", "KOTAKB", "YESBNK",
        "INDUSB", "PNBSMS", "BOBIBS", "CANBNK", "UNIONB", "CENTBK",
        "IPPBSMS", "PAYTM", "GPAY", "PHONEPE", "AMAZONP", "FREECRG",
        "CITI", "HSBC", "SCBNK", "DEUBNK", "AMEX", "VM-HDFCBK"
    )

    // Merchant category mapping by keywords
    private val MERCHANT_CATEGORIES = mapOf(
        listOf("swiggy", "zomato", "uber eats", "domino", "pizza", "restaurant", "cafe", "hotel", "food", "eat") to "Food & Dining",
        listOf("bigbasket", "grofer", "dmart", "reliance fresh", "more", "supermarket", "grocery", "kirana") to "Groceries",
        listOf("uber", "ola", "rapido", "metro", "irctc", "railway", "bus", "petrol", "fuel", "parking", "fastag") to "Transportation",
        listOf("amazon", "flipkart", "myntra", "nykaa", "meesho", "ajio", "shopsy", "mall", "store", "shop") to "Shopping",
        listOf("netflix", "hotstar", "prime", "spotify", "youtube", "cinema", "pvr", "inox", "bookmyshow") to "Entertainment",
        listOf("electricity", "water", "gas", "broadband", "airtel", "jio", "vi", "bsnl", "postpaid", "recharge", "bill") to "Utilities",
        listOf("hospital", "clinic", "pharmacy", "medplus", "apollo", "fortis", "doctor", "medicine", "health") to "Health & Medical",
        listOf("school", "college", "university", "tuition", "course", "udemy", "coursera", "byju") to "Education",
        listOf("flight", "makemytrip", "goibibo", "cleartrip", "hotel booking", "oyo", "airbnb", "travel") to "Travel",
        listOf("atm", "cash withdrawal", "atm withdrawal") to "ATM Withdrawal",
        listOf("lic", "insurance", "premium", "policy") to "Insurance"
    )

    // Account number patterns
    private val ACCOUNT_PATTERN = Pattern.compile("""(?:a/?c|acct?|account)[\s.#:]*(?:no\.?)?\s*[xX*]{0,10}(\d{4})""", Pattern.CASE_INSENSITIVE)
    private val CARD_PATTERN = Pattern.compile("""card\s+(?:ending|no\.?|number)?\s*[xX*]*(\d{4})""", Pattern.CASE_INSENSITIVE)

    fun parse(sender: String, body: String): ParseResult {
        val upperBody = body.uppercase()
        val lowerBody = body.lowercase()

        // Quick rejection: not a financial SMS
        if (!looksLikeFinancialSms(upperBody)) {
            return ParseResult(null, 0f)
        }

        val amount = extractAmount(body) ?: return ParseResult(null, 0.1f)
        val type = determineTransactionType(lowerBody)
        val merchant = extractMerchant(body)
        val category = categorize(lowerBody, merchant, type)
        val accountLast4 = extractAccountLast4(body)
        val description = buildDescription(body, merchant, type)
        val date = Date() // SMS timestamp is current time; SMS delivery timestamp is used in receiver

        val confidence = calculateConfidence(body, amount, type)

        return ParseResult(
            Transaction(
                amount = amount,
                type = type,
                category = category,
                description = description,
                merchant = merchant,
                date = date,
                source = TransactionSource.SMS,
                rawMessage = body.take(500), // store trimmed raw
                isVerified = confidence > 0.7f,
                accountLast4 = accountLast4
            ),
            confidence
        )
    }

    private fun looksLikeFinancialSms(upper: String): Boolean {
        val financialKeywords = listOf(
            "DEBITED", "CREDITED", "TRANSACTION", "PAYMENT", "TRANSFERRED",
            "WITHDRAWN", "BALANCE", "RUPEE", "INR", "RS.", "₹", "AMOUNT",
            "ACCOUNT", "CARD", "UPI", "NEFT", "IMPS", "RTGS", "EMI"
        )
        return financialKeywords.any { upper.contains(it) }
    }

    private fun extractAmount(body: String): Double? {
        for (pattern in AMOUNT_PATTERNS) {
            val matcher = pattern.matcher(body)
            if (matcher.find()) {
                val amountStr = matcher.group(1)?.replace(",", "") ?: continue
                val amount = amountStr.toDoubleOrNull() ?: continue
                if (amount > 0 && amount < 10_000_000) return amount
            }
        }
        return null
    }

    private fun determineTransactionType(lower: String): TransactionType {
        val debitScore = DEBIT_KEYWORDS.count { lower.contains(it) }
        val creditScore = CREDIT_KEYWORDS.count { lower.contains(it) }
        val transferScore = TRANSFER_OUT_KEYWORDS.count { lower.contains(it) }

        return when {
            transferScore > 0 -> TransactionType.TRANSFER
            debitScore > creditScore -> TransactionType.EXPENSE
            creditScore > debitScore -> TransactionType.INCOME
            lower.contains("debit") -> TransactionType.EXPENSE
            lower.contains("credit") -> TransactionType.INCOME
            else -> TransactionType.EXPENSE // default to expense
        }
    }

    private fun extractMerchant(body: String): String {
        val patterns = listOf(
            Pattern.compile("""(?:at|to|from|merchant|vendor)\s+([A-Z][A-Za-z0-9 &'-]{2,30})"""),
            Pattern.compile("""(?:purchase at|transaction at|paid to|sent to)\s+([A-Z][A-Za-z0-9 &'-]{2,30})""", Pattern.CASE_INSENSITIVE),
            Pattern.compile("""(?:Info:)\s*([A-Za-z0-9 &'-]{3,30})""", Pattern.CASE_INSENSITIVE)
        )
        for (p in patterns) {
            val m = p.matcher(body)
            if (m.find()) {
                val candidate = m.group(1)?.trim() ?: continue
                // Filter out generic words
                if (candidate.length > 2 && !candidate.uppercase().matches(Regex("(YOUR|THE|FOR|ON|VIA|BY|FROM|TO|AT|A/C|ACCT)"))) {
                    return candidate
                }
            }
        }
        return ""
    }

    private fun categorize(lower: String, merchant: String, type: TransactionType): String {
        val searchText = "$lower ${merchant.lowercase()}"

        // Check transfer first
        if (type == TransactionType.TRANSFER) return "Transfer Sent"

        // ATM
        if (searchText.contains("atm") || searchText.contains("cash withdrawal")) return "ATM Withdrawal"

        // Salary
        if (searchText.contains("salary") || searchText.contains("payroll") || searchText.contains("wages")) return "Salary"

        // Refund
        if (searchText.contains("refund") || searchText.contains("cashback")) return "Refund"

        // Match merchant categories
        for ((keywords, category) in MERCHANT_CATEGORIES) {
            if (keywords.any { searchText.contains(it) }) {
                return if (type == TransactionType.INCOME && category !in Categories.INCOME_CATEGORIES) {
                    "Other Income"
                } else {
                    category
                }
            }
        }

        return if (type == TransactionType.INCOME) "Other Income" else "Other"
    }

    private fun extractAccountLast4(body: String): String {
        val accountMatcher = ACCOUNT_PATTERN.matcher(body)
        if (accountMatcher.find()) return accountMatcher.group(1) ?: ""
        val cardMatcher = CARD_PATTERN.matcher(body)
        if (cardMatcher.find()) return cardMatcher.group(1) ?: ""
        return ""
    }

    private fun buildDescription(body: String, merchant: String, type: TransactionType): String {
        val prefix = when (type) {
            TransactionType.INCOME -> "Received"
            TransactionType.EXPENSE -> "Payment"
            TransactionType.TRANSFER -> "Transfer"
        }
        return if (merchant.isNotBlank()) "$prefix - $merchant"
        else prefix + ": " + body.take(60).replace("\n", " ").trim()
    }

    private fun calculateConfidence(body: String, amount: Double, type: TransactionType): Float {
        var score = 0.5f
        if (amount > 0) score += 0.2f
        if (body.contains(Regex("(?i)balance"))) score += 0.1f
        if (body.contains(Regex("(?i)(UPI|NEFT|IMPS|RTGS|ATM)"))) score += 0.15f
        if (body.contains(Regex("(?i)a/?c|account"))) score += 0.05f
        return score.coerceIn(0f, 1f)
    }
}
