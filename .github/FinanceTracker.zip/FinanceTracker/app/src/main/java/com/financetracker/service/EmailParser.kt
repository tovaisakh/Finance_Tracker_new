package com.financetracker.service

import android.content.Context
import android.content.SharedPreferences
import com.financetracker.data.Transaction
import com.financetracker.data.TransactionSource
import com.financetracker.data.TransactionType
import java.util.*
import java.util.regex.Pattern

/**
 * EmailParser: Parses financial emails retrieved from Gmail/other providers
 * via their REST APIs. This handles email body text once fetched.
 */
object EmailParser {

    data class EmailParseResult(
        val transaction: Transaction?,
        val confidence: Float
    )

    private val AMOUNT_PATTERNS = listOf(
        Pattern.compile("""(?:Rs\.?|INR|₹)\s*([0-9,]+(?:\.[0-9]{1,2})?)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""(?:USD|EUR|GBP)\s*([0-9,]+(?:\.[0-9]{1,2})?)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""Total[:\s]+(?:Rs\.?|INR|₹|USD|EUR)?\s*([0-9,]+(?:\.[0-9]{1,2})?)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""Amount[:\s]+(?:Rs\.?|INR|₹|USD|EUR)?\s*([0-9,]+(?:\.[0-9]{1,2})?)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""Order Total[:\s]+(?:Rs\.?|INR|₹)?\s*([0-9,]+(?:\.[0-9]{1,2})?)""", Pattern.CASE_INSENSITIVE)
    )

    private val FINANCIAL_EMAIL_SENDERS = setOf(
        "noreply@hdfcbank.com", "alerts@icicibank.com", "alerts@sbi.co.in",
        "alerts@axisbank.com", "noreply@kotak.com", "no-reply@paytm.com",
        "noreply@amazon.in", "receipts@swiggy.in", "noreply@zomato.com",
        "noreply@uber.com", "no-reply@phonepe.com"
    )

    private val TRANSACTION_SUBJECT_PATTERNS = listOf(
        Pattern.compile("""(?:payment|transaction|purchase|order|receipt|invoice|confirmation|statement)""", Pattern.CASE_INSENSITIVE),
        Pattern.compile("""(?:debited|credited|transferred|charged|refund)""", Pattern.CASE_INSENSITIVE)
    )

    fun isFinancialEmail(sender: String, subject: String): Boolean {
        val senderLower = sender.lowercase()
        if (FINANCIAL_EMAIL_SENDERS.any { senderLower.contains(it) }) return true
        val subjectLower = subject.lowercase()
        return TRANSACTION_SUBJECT_PATTERNS.any { it.matcher(subjectLower).find() }
    }

    fun parse(sender: String, subject: String, body: String, receivedDate: Date): EmailParseResult {
        val combinedText = "$subject\n$body"
        val lower = combinedText.lowercase()

        if (!isFinancialEmail(sender, subject)) {
            return EmailParseResult(null, 0f)
        }

        val amount = extractAmount(combinedText) ?: return EmailParseResult(null, 0.2f)
        val type = determineType(lower)
        val merchant = extractMerchantFromEmail(sender, subject, body)
        val category = SmsParser.run {
            // Reuse SMS categorization logic
        }.let {
            categorizFromEmail(lower, merchant, type)
        }
        val description = buildDescription(subject, merchant, type)

        return EmailParseResult(
            Transaction(
                amount = amount,
                type = type,
                category = category,
                description = description,
                merchant = merchant,
                date = receivedDate,
                source = TransactionSource.EMAIL,
                rawMessage = body.take(500),
                isVerified = true
            ),
            0.75f
        )
    }

    private fun extractAmount(text: String): Double? {
        for (pattern in AMOUNT_PATTERNS) {
            val matcher = pattern.matcher(text)
            if (matcher.find()) {
                val raw = matcher.group(1)?.replace(",", "") ?: continue
                val amount = raw.toDoubleOrNull() ?: continue
                if (amount > 0 && amount < 10_000_000) return amount
            }
        }
        return null
    }

    private fun determineType(lower: String): TransactionType {
        val debitWords = setOf("debited", "charged", "paid", "payment", "purchase", "order confirmed", "subscription renewed")
        val creditWords = setOf("credited", "refund", "cashback", "received", "salary")
        val transferWords = setOf("transferred to", "sent to", "wire transfer")

        val debit = debitWords.count { lower.contains(it) }
        val credit = creditWords.count { lower.contains(it) }
        val transfer = transferWords.count { lower.contains(it) }

        return when {
            transfer > 0 -> TransactionType.TRANSFER
            credit > debit -> TransactionType.INCOME
            else -> TransactionType.EXPENSE
        }
    }

    private fun extractMerchantFromEmail(sender: String, subject: String, body: String): String {
        // Extract domain from sender email
        val domain = sender.substringAfter("@").substringBefore(".")
            .replaceFirstChar { it.uppercaseChar() }

        // Check subject for merchant name patterns
        val subjectPatterns = listOf(
            Pattern.compile("""(?:from|at|by)\s+([A-Za-z0-9 &'-]{3,30})""", Pattern.CASE_INSENSITIVE),
            Pattern.compile("""(?:Order from|Purchase from|Payment to)\s+([A-Za-z0-9 &'-]{3,30})""", Pattern.CASE_INSENSITIVE)
        )
        for (p in subjectPatterns) {
            val m = p.matcher(subject)
            if (m.find()) return m.group(1)?.trim() ?: domain
        }

        return domain
    }

    private fun categorizFromEmail(lower: String, merchant: String, type: TransactionType): String {
        if (type == TransactionType.TRANSFER) return "Transfer Sent"
        if (lower.contains("salary") || lower.contains("payroll")) return "Salary"
        if (lower.contains("refund") || lower.contains("cashback")) return "Refund"

        val merchantLower = merchant.lowercase()
        return when {
            listOf("amazon", "flipkart", "myntra").any { merchantLower.contains(it) } -> "Shopping"
            listOf("swiggy", "zomato", "restaurant").any { merchantLower.contains(it) } -> "Food & Dining"
            listOf("uber", "ola", "metro").any { merchantLower.contains(it) } -> "Transportation"
            listOf("netflix", "spotify", "prime").any { merchantLower.contains(it) } -> "Subscriptions"
            type == TransactionType.INCOME -> "Other Income"
            else -> "Other"
        }
    }

    private fun buildDescription(subject: String, merchant: String, type: TransactionType): String {
        val cleaned = subject.take(80).replace(Regex("""[^\w\s,.-]"""), "").trim()
        return if (cleaned.isNotBlank()) cleaned else "$type from $merchant"
    }
}
