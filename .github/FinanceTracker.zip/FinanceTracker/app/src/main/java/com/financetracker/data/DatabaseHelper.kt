package com.financetracker.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Date

class DatabaseHelper(context: Context) : SQLiteOpenHelper(
    context, DATABASE_NAME, null, DATABASE_VERSION
) {

    companion object {
        private const val DATABASE_NAME = "finance_tracker.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_TRANSACTIONS = "transactions"
        const val COL_ID = "_id"
        const val COL_AMOUNT = "amount"
        const val COL_TYPE = "type"
        const val COL_CATEGORY = "category"
        const val COL_DESCRIPTION = "description"
        const val COL_MERCHANT = "merchant"
        const val COL_DATE = "date"
        const val COL_SOURCE = "source"
        const val COL_RAW_MESSAGE = "raw_message"
        const val COL_IS_VERIFIED = "is_verified"
        const val COL_ACCOUNT_LAST4 = "account_last4"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_TRANSACTIONS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_AMOUNT REAL NOT NULL,
                $COL_TYPE TEXT NOT NULL,
                $COL_CATEGORY TEXT NOT NULL,
                $COL_DESCRIPTION TEXT,
                $COL_MERCHANT TEXT,
                $COL_DATE INTEGER NOT NULL,
                $COL_SOURCE TEXT NOT NULL,
                $COL_RAW_MESSAGE TEXT,
                $COL_IS_VERIFIED INTEGER DEFAULT 1,
                $COL_ACCOUNT_LAST4 TEXT
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_TRANSACTIONS")
        onCreate(db)
    }

    fun insertTransaction(transaction: Transaction): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_AMOUNT, transaction.amount)
            put(COL_TYPE, transaction.type.name)
            put(COL_CATEGORY, transaction.category)
            put(COL_DESCRIPTION, transaction.description)
            put(COL_MERCHANT, transaction.merchant)
            put(COL_DATE, transaction.date.time)
            put(COL_SOURCE, transaction.source.name)
            put(COL_RAW_MESSAGE, transaction.rawMessage)
            put(COL_IS_VERIFIED, if (transaction.isVerified) 1 else 0)
            put(COL_ACCOUNT_LAST4, transaction.accountLast4)
        }
        return db.insert(TABLE_TRANSACTIONS, null, values)
    }

    fun updateTransaction(transaction: Transaction): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_AMOUNT, transaction.amount)
            put(COL_TYPE, transaction.type.name)
            put(COL_CATEGORY, transaction.category)
            put(COL_DESCRIPTION, transaction.description)
            put(COL_MERCHANT, transaction.merchant)
            put(COL_DATE, transaction.date.time)
            put(COL_IS_VERIFIED, if (transaction.isVerified) 1 else 0)
        }
        return db.update(TABLE_TRANSACTIONS, values, "$COL_ID=?", arrayOf(transaction.id.toString()))
    }

    fun deleteTransaction(id: Long): Int {
        val db = writableDatabase
        return db.delete(TABLE_TRANSACTIONS, "$COL_ID=?", arrayOf(id.toString()))
    }

    fun getAllTransactions(
        limit: Int = -1,
        type: TransactionType? = null,
        category: String? = null,
        searchQuery: String? = null,
        startDate: Date? = null,
        endDate: Date? = null
    ): List<Transaction> {
        val db = readableDatabase
        val conditions = mutableListOf<String>()
        val args = mutableListOf<String>()

        type?.let { conditions.add("$COL_TYPE = ?"); args.add(it.name) }
        category?.let { conditions.add("$COL_CATEGORY = ?"); args.add(it) }
        searchQuery?.let {
            conditions.add("($COL_DESCRIPTION LIKE ? OR $COL_MERCHANT LIKE ?)")
            args.add("%$it%"); args.add("%$it%")
        }
        startDate?.let { conditions.add("$COL_DATE >= ?"); args.add(it.time.toString()) }
        endDate?.let { conditions.add("$COL_DATE <= ?"); args.add(it.time.toString()) }

        val where = if (conditions.isEmpty()) null else conditions.joinToString(" AND ")
        val limitStr = if (limit > 0) limit.toString() else null

        val cursor = db.query(
            TABLE_TRANSACTIONS, null, where, args.toTypedArray(),
            null, null, "$COL_DATE DESC", limitStr
        )

        val transactions = mutableListOf<Transaction>()
        cursor.use {
            while (it.moveToNext()) {
                transactions.add(
                    Transaction(
                        id = it.getLong(it.getColumnIndexOrThrow(COL_ID)),
                        amount = it.getDouble(it.getColumnIndexOrThrow(COL_AMOUNT)),
                        type = TransactionType.valueOf(it.getString(it.getColumnIndexOrThrow(COL_TYPE))),
                        category = it.getString(it.getColumnIndexOrThrow(COL_CATEGORY)),
                        description = it.getString(it.getColumnIndexOrThrow(COL_DESCRIPTION)) ?: "",
                        merchant = it.getString(it.getColumnIndexOrThrow(COL_MERCHANT)) ?: "",
                        date = Date(it.getLong(it.getColumnIndexOrThrow(COL_DATE))),
                        source = TransactionSource.valueOf(it.getString(it.getColumnIndexOrThrow(COL_SOURCE))),
                        rawMessage = it.getString(it.getColumnIndexOrThrow(COL_RAW_MESSAGE)) ?: "",
                        isVerified = it.getInt(it.getColumnIndexOrThrow(COL_IS_VERIFIED)) == 1,
                        accountLast4 = it.getString(it.getColumnIndexOrThrow(COL_ACCOUNT_LAST4)) ?: ""
                    )
                )
            }
        }
        return transactions
    }

    fun getTotalByType(type: TransactionType, startDate: Date? = null, endDate: Date? = null): Double {
        val db = readableDatabase
        val conditions = mutableListOf("$COL_TYPE = ?")
        val args = mutableListOf(type.name)

        startDate?.let { conditions.add("$COL_DATE >= ?"); args.add(it.time.toString()) }
        endDate?.let { conditions.add("$COL_DATE <= ?"); args.add(it.time.toString()) }

        val cursor = db.rawQuery(
            "SELECT SUM($COL_AMOUNT) FROM $TABLE_TRANSACTIONS WHERE ${conditions.joinToString(" AND ")}",
            args.toTypedArray()
        )
        return cursor.use { if (it.moveToFirst()) it.getDouble(0) else 0.0 }
    }

    fun getCategoryTotals(type: TransactionType, startDate: Date? = null, endDate: Date? = null): Map<String, Double> {
        val db = readableDatabase
        val conditions = mutableListOf("$COL_TYPE = ?")
        val args = mutableListOf(type.name)
        startDate?.let { conditions.add("$COL_DATE >= ?"); args.add(it.time.toString()) }
        endDate?.let { conditions.add("$COL_DATE <= ?"); args.add(it.time.toString()) }

        val cursor = db.rawQuery(
            "SELECT $COL_CATEGORY, SUM($COL_AMOUNT) FROM $TABLE_TRANSACTIONS WHERE ${conditions.joinToString(" AND ")} GROUP BY $COL_CATEGORY ORDER BY SUM($COL_AMOUNT) DESC",
            args.toTypedArray()
        )
        val result = mutableMapOf<String, Double>()
        cursor.use {
            while (it.moveToNext()) {
                result[it.getString(0)] = it.getDouble(1)
            }
        }
        return result
    }

    fun isDuplicateTransaction(amount: Double, date: Date, description: String): Boolean {
        val db = readableDatabase
        // Check within 5 minutes window for duplicate detection
        val window = 5 * 60 * 1000L
        val cursor = db.rawQuery(
            "SELECT COUNT(*) FROM $TABLE_TRANSACTIONS WHERE $COL_AMOUNT = ? AND $COL_DATE BETWEEN ? AND ? AND $COL_DESCRIPTION = ?",
            arrayOf(amount.toString(), (date.time - window).toString(), (date.time + window).toString(), description)
        )
        return cursor.use { it.moveToFirst() && it.getInt(0) > 0 }
    }
}
