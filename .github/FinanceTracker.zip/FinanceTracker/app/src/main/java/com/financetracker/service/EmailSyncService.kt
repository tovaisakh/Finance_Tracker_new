package com.financetracker.service

import android.app.Service
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.IBinder
import android.provider.BaseColumns
import android.util.Log
import com.financetracker.data.DatabaseHelper
import java.util.Date

/**
 * Reads existing SMS messages from device inbox on first launch,
 * and scans Gmail using Content Provider (if available).
 */
class EmailSyncService : Service() {

    companion object {
        private const val TAG = "FinanceTracker.Email"
        const val ACTION_SCAN_INBOX = "com.financetracker.SCAN_INBOX"
        const val ACTION_SCAN_SMS_HISTORY = "com.financetracker.SCAN_SMS_HISTORY"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SCAN_SMS_HISTORY -> {
                Thread { scanSmsHistory() }.start()
            }
            ACTION_SCAN_INBOX -> {
                Thread { scanGmailEmails() }.start()
            }
        }
        return START_NOT_STICKY
    }

    private fun scanSmsHistory() {
        val dbHelper = DatabaseHelper(this)
        try {
            val uri = Uri.parse("content://sms/inbox")
            val cursor: Cursor? = contentResolver.query(
                uri,
                arrayOf("_id", "address", "body", "date"),
                null, null,
                "date DESC LIMIT 500"
            )

            cursor?.use {
                var count = 0
                while (it.moveToNext()) {
                    val sender = it.getString(it.getColumnIndexOrThrow("address")) ?: continue
                    val body = it.getString(it.getColumnIndexOrThrow("body")) ?: continue
                    val dateMs = it.getLong(it.getColumnIndexOrThrow("date"))
                    val date = Date(dateMs)

                    val result = SmsParser.parse(sender, body)
                    val transaction = result.transaction ?: continue
                    val withDate = transaction.copy(date = date)

                    if (!dbHelper.isDuplicateTransaction(withDate.amount, withDate.date, withDate.description)) {
                        dbHelper.insertTransaction(withDate)
                        count++
                    }
                }
                Log.d(TAG, "Imported $count transactions from SMS history")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error scanning SMS history", e)
        }
        stopSelf()
    }

    private fun scanGmailEmails() {
        // Gmail scanning requires OAuth2 - guide users through Gmail API setup
        // This is handled via the Setup wizard in the UI
        Log.d(TAG, "Gmail scan requires OAuth setup via settings")
        stopSelf()
    }
}
