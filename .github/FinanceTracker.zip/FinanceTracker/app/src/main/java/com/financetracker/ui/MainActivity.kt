package com.financetracker.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.financetracker.R
import com.financetracker.databinding.ActivityMainBinding
import com.financetracker.service.EmailSyncService
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val PERMISSION_REQUEST_CODE = 100
    private val REQUIRED_PERMISSIONS = mutableListOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS
    ).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupBottomNavigation()

        if (savedInstanceState == null) {
            loadFragment(DashboardFragment())
            checkAndRequestPermissions()
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> loadFragment(DashboardFragment())
                R.id.nav_transactions -> loadFragment(TransactionsFragment())
                R.id.nav_analytics -> loadFragment(AnalyticsFragment())
                R.id.nav_add -> {
                    startActivity(Intent(this, AddTransactionActivity::class.java))
                    return@setOnItemSelectedListener false
                }
            }
            true
        }
    }

    private fun loadFragment(fragment: Fragment): Boolean {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
        return true
    }

    private fun checkAndRequestPermissions() {
        val missing = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isEmpty()) {
            onPermissionsGranted()
        } else {
            showPermissionRationale(missing.toTypedArray())
        }
    }

    private fun showPermissionRationale(permissions: Array<String>) {
        AlertDialog.Builder(this)
            .setTitle("📊 Permissions Required")
            .setMessage(
                "FinanceTracker needs the following permissions to automatically track your finances:\n\n" +
                "• SMS: To detect bank transaction alerts\n" +
                "• Notifications: To alert you about new transactions\n\n" +
                "Your data stays private and stored only on this device."
            )
            .setPositiveButton("Grant Permissions") { _, _ ->
                ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE)
            }
            .setNegativeButton("Maybe Later") { _, _ ->
                showManualNote()
            }
            .setCancelable(false)
            .show()
    }

    private fun showManualNote() {
        binding.permissionBanner.visibility = View.VISIBLE
        binding.permissionBanner.setOnClickListener {
            checkAndRequestPermissions()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (allGranted) {
                onPermissionsGranted()
            } else {
                showManualNote()
            }
        }
    }

    private fun onPermissionsGranted() {
        binding.permissionBanner.visibility = View.GONE
        // Scan existing SMS on first run
        val prefs = getSharedPreferences("finance_tracker", MODE_PRIVATE)
        if (!prefs.getBoolean("initial_scan_done", false)) {
            startService(Intent(this, EmailSyncService::class.java).apply {
                action = EmailSyncService.ACTION_SCAN_SMS_HISTORY
            })
            prefs.edit().putBoolean("initial_scan_done", true).apply()
        }
    }
}
