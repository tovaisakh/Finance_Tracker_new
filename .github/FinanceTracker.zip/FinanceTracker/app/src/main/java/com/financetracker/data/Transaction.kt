package com.financetracker.data

import java.util.Date

data class Transaction(
    val id: Long = 0,
    val amount: Double,
    val type: TransactionType,
    val category: String,
    val description: String,
    val merchant: String = "",
    val date: Date,
    val source: TransactionSource,
    val rawMessage: String = "",
    val isVerified: Boolean = true,
    val accountLast4: String = ""
) {
    val formattedAmount: String
        get() = if (type == TransactionType.INCOME) "+₹%.2f".format(amount)
                else "-₹%.2f".format(amount)
}

enum class TransactionType {
    INCOME, EXPENSE, TRANSFER
}

enum class TransactionSource {
    SMS, EMAIL, MANUAL
}

object Categories {
    val EXPENSE_CATEGORIES = listOf(
        "Food & Dining",
        "Groceries",
        "Transportation",
        "Shopping",
        "Entertainment",
        "Utilities",
        "Health & Medical",
        "Education",
        "Travel",
        "Transfer Sent",
        "ATM Withdrawal",
        "Rent & Housing",
        "Insurance",
        "Subscriptions",
        "Other"
    )

    val INCOME_CATEGORIES = listOf(
        "Salary",
        "Freelance",
        "Transfer Received",
        "Interest",
        "Refund",
        "Investment Returns",
        "Rental Income",
        "Other Income"
    )

    val ALL_CATEGORIES = EXPENSE_CATEGORIES + INCOME_CATEGORIES

    val CATEGORY_ICONS = mapOf(
        "Food & Dining" to "🍽️",
        "Groceries" to "🛒",
        "Transportation" to "🚗",
        "Shopping" to "🛍️",
        "Entertainment" to "🎬",
        "Utilities" to "💡",
        "Health & Medical" to "🏥",
        "Education" to "📚",
        "Travel" to "✈️",
        "Transfer Sent" to "💸",
        "ATM Withdrawal" to "🏧",
        "Rent & Housing" to "🏠",
        "Insurance" to "🛡️",
        "Subscriptions" to "📱",
        "Other" to "📌",
        "Salary" to "💼",
        "Freelance" to "💻",
        "Transfer Received" to "💰",
        "Interest" to "🏦",
        "Refund" to "↩️",
        "Investment Returns" to "📈",
        "Rental Income" to "🏡",
        "Other Income" to "💹"
    )
}
