# Finance Tracker ProGuard rules

# Keep data models
-keep class com.financetracker.data.** { *; }

# Keep Kotlin metadata
-keep class kotlin.Metadata { *; }
-keepclassmembers class **$WhenMappings { <fields>; }

# Material Components
-keep class com.google.android.material.** { *; }

# AndroidX
-keep class androidx.** { *; }

# SQLite
-keep class android.database.** { *; }

# Suppress warnings for unused classes
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
